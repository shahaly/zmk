# zmk-config

A ZMK-ized version of my keymap, using a custom Absolem PCB shield.
Huge thanks to @davidphilipbarr, who prepared a template for me, so I only had to tweak things here and there!
